// ============================================================================
// scripts/build-map.mjs
// Перетворює експорт TileWeaver (.json) на два файли:
//   data/server-map.json        — для СЕРВЕРА: межі, колізії, спавни (кілька КБ)
//   public/assets/map.json      — для КЛІЄНТА: що і де малювати
//   public/assets/tiles/*.png   — картинки тайлів (замість base64 у json)
// Запуск:  npm run build-map -- шлях/до/tileweaver_Map.json
// ============================================================================
import fs from "node:fs";
import path from "node:path";

const src = process.argv[2];
if (!src) {
  console.error("Використання: npm run build-map -- <tileweaver.json>");
  process.exit(1);
}
const raw = JSON.parse(fs.readFileSync(src, "utf8"));

const OUT_TILES = "public/assets/tiles";
fs.rmSync(OUT_TILES, { recursive: true, force: true });
fs.mkdirSync(OUT_TILES, { recursive: true });
fs.mkdirSync("data", { recursive: true });

/** Читає ширину/висоту PNG з його заголовка (без бібліотек). */
function pngSize(buf) {
  return { w: buf.readUInt32BE(16), h: buf.readUInt32BE(20) };
}

// --- 1. Тайли, які реально використані на карті -----------------------------
const usedIds = new Set(raw.placements.map((p) => p.tileId));
const tiles = {};
for (const id of usedIds) {
  const t = raw.tiles[id];
  if (!t) continue;
  const buf = Buffer.from(t.dataURL.split(",")[1], "base64");
  fs.writeFileSync(path.join(OUT_TILES, `${id}.png`), buf);
  const { w, h } = pngSize(buf);
  tiles[id] = {
    w,
    h,
    // pivot: частка (0..1) ширини/висоти; використовується для сортування по глибині
    px: t.pivotX ?? 0.5,
    py: t.pivotY ?? 1,
    // анімовані тайли: кадри йдуть горизонтальною стрічкою
    frames: t.animFrames ? Number(t.animFrames) : 1,
    frameMs: t.animFrameMs ? Number(t.animFrameMs) : 1000,
  };
}

// --- 2. Розміщення (мінімум полів) ------------------------------------------
// Формат кожного елемента: [tileId, x, y, z, flipX(0/1), isRoof(0/1)]
const placements = raw.placements
  .filter((p) => tiles[p.tileId])
  .map((p) => [p.tileId, p.x, p.y, p.z, p.flipX ? 1 : 0, p.isRoof ? 1 : 0]);

// --- 3. Межі світу: за розміщеними тайлами + відступ ------------------------
let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
for (const p of raw.placements) {
  const t = tiles[p.tileId];
  if (!t) continue;
  minX = Math.min(minX, p.x);
  minY = Math.min(minY, p.y);
  maxX = Math.max(maxX, p.x + t.w);
  maxY = Math.max(maxY, p.y + t.h);
}
const PAD = 16;
const bounds = { minX: minX + PAD, minY: minY + PAD, maxX: maxX - PAD, maxY: maxY - PAD };

// --- 4. Колізії і спавни для сервера ----------------------------------------
const collisions = raw.collisions
  .filter((c) => c.shape === "poly" && c.type === "solid")
  .map((c) => ({ id: c.id, pts: c.pts.map((q) => [q.x, q.y]) }));
const spawns = (raw.spawns || []).map((s) => ({ x: s.x, y: s.y }));

fs.writeFileSync("data/server-map.json", JSON.stringify({ name: raw.name, bounds, collisions, spawns }));
fs.writeFileSync("public/assets/map.json", JSON.stringify({ name: raw.name, bounds, tiles, placements }));

// Для режиму ?debug у клієнті (малює колізії поверх карти). Грі НЕ потрібен.
fs.writeFileSync("public/assets/debug-collisions.json", JSON.stringify(collisions.map((c) => c.pts)));

console.log(`Карта "${raw.name}": ${placements.length} тайлів, ${Object.keys(tiles).length} картинок, ${collisions.length} колізій, ${spawns.length} спавнів`);
console.log("Межі:", bounds);
