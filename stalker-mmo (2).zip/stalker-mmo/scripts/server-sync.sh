#!/usr/bin/env bash
# ============================================================================
# Автооновлення гри на сервері з GitHub. Один раз ставиш — далі сервер сам
# раз на хвилину дивиться, чи є нові файли в репозиторії, і якщо є —
# оновлює, збирає і перезапускає гру. Заходити по SSH більше не треба.
#
# Перший раз (в SSH-вікні сервера):
#   git clone https://github.com/ТВІЙ_НІК/РЕПОЗИТОРІЙ ~/zona
#   bash ~/zona/scripts/server-sync.sh --install
#
# Режими:  --install  поставити все й запустити стеження
#          --watch    нескінченний цикл стеження (його запускає pm2)
#          --once     одна перевірка/оновлення (за замовчуванням)
# Секрети (необов'язково): файл ~/zona.env з рядками SUPABASE_URL=... і SUPABASE_SERVICE_KEY=...
# ============================================================================
set -e
DIR="${ZONA_DIR:-$HOME/zona}"      # куди склоновано репозиторій
SELF="$DIR/scripts/server-sync.sh"
APP="zona"                         # назва процесу гри в pm2
WATCHER="zona-watch"               # назва процесу-наглядача в pm2
REV_FILE="$DIR/.deployed-rev"      # яка версія зараз запущена
LOG="$HOME/zona-sync.log"

# Увесь код у функціях і виклик в останньому рядку: так bash прочитає файл
# повністю, і оновлення самого скрипта посеред роботи нічого не ламає.

ensure_tools() {
  command -v git >/dev/null || sudo apt-get install -y git
  command -v npm >/dev/null || { sudo apt-get update -y && sudo apt-get install -y npm; }
  command -v pm2 >/dev/null || sudo npm install -g pm2
}

load_env() {
  if [ -f "$HOME/zona.env" ]; then set -a; . "$HOME/zona.env"; set +a; fi
  export PORT="${PORT:-7860}"
}

deploy() {
  cd "$DIR"
  npm install --no-audit --no-fund
  npm run build
  load_env
  if pm2 describe "$APP" >/dev/null 2>&1; then
    pm2 restart "$APP" --update-env
  else
    pm2 start dist/server.js --name "$APP" --cwd "$DIR"
  fi
  pm2 save >/dev/null
}

sync_once() {
  [ -d "$DIR/.git" ] || { echo "Немає репозиторію в $DIR. Спочатку: git clone <адреса> $DIR"; exit 1; }
  cd "$DIR"
  git fetch -q origin
  local branch remote deployed=""
  branch=$(git rev-parse --abbrev-ref HEAD)
  remote=$(git rev-parse "origin/$branch")
  [ -f "$REV_FILE" ] && deployed=$(cat "$REV_FILE")
  if [ "$remote" != "$deployed" ] || [ ! -f dist/server.js ]; then
    echo "[$(date '+%F %T')] Оновлення до ${remote:0:7}"
    git reset -q --hard "origin/$branch"
    deploy
    echo "$remote" > "$REV_FILE"   # записуємо ТІЛЬКИ після успішної збірки
    echo "[$(date '+%F %T')] Готово"
  fi
}

install_all() {
  ensure_tools
  sync_once
  pm2 delete "$WATCHER" >/dev/null 2>&1 || true
  pm2 start "$SELF" --name "$WATCHER" --interpreter bash -- --watch
  pm2 save >/dev/null
  sudo env PATH="$PATH" pm2 startup systemd -u "$USER" --hp "$HOME" >/dev/null 2>&1 || true
  local ip
  ip=$(curl -s -H "Metadata-Flavor: Google" \
    http://metadata.google.internal/computeMetadata/v1/instance/network-interfaces/0/access-configs/0/external-ip || true)
  echo "Все працює. Гра: http://${ip:-IP_СЕРВЕРА}:${PORT:-7860}"
  echo "Далі сервер сам оновлюватиметься з GitHub. Журнал: $LOG"
}

watch_loop() {
  while true; do
    bash "$SELF" --once >> "$LOG" 2>&1 || true   # щоразу запускається найновіша версія скрипта
    sleep 60
  done
}

main() {
  case "${1:---once}" in
    --install) install_all ;;
    --watch)   watch_loop ;;
    *)         ensure_tools; sync_once ;;
  esac
}
main "$@"; exit $?
