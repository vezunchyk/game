// ============================================================================
// scripts/build.mjs — збирає сервер (dist/server.js) і клієнт (public/game.js)
// ============================================================================
import { build } from "esbuild";

await build({
  entryPoints: ["server/index.ts"], outfile: "dist/server.js",
  bundle: true, platform: "node", format: "esm", target: "node22",
  packages: "external", // ws лишається в node_modules
});
await build({
  entryPoints: ["client/main.ts"], outfile: "public/game.js",
  bundle: true, platform: "browser", format: "iife", target: "es2020", minify: false,
});
console.log("Збірка готова.");
