// ============================================================================
// client/render/MapRenderer.ts
// Малює карту з TileWeaver. Карта статична, тому один раз сортуємо,
// а кожен кадр малюємо лише те, що потрапляє в кадр камери.
//
// ПОРЯДОК МАЛЮВАННЯ (глибина):
//   1. "Земля" — тайли з z < GROUND_Z_LIMIT: завжди під гравцями.
//   2. Решта (стіни, дахи, предмети) разом із гравцями сортуються по "низу"
//      (sortY): хто нижче на екрані — той ближче до глядача, малюється пізніше.
// Якщо у твоєму редакторі глибина працює інакше — міняти тільки тут.
// ============================================================================

/** Тайли з z нижче цього значення вважаються підлогою (завжди під гравцями). */
const GROUND_Z_LIMIT = 20;

interface TileInfo { w: number; h: number; px: number; py: number; frames: number; frameMs: number; }
interface MapFile {
  bounds: { minX: number; minY: number; maxX: number; maxY: number };
  tiles: Record<string, TileInfo>;
  /** [tileId, x, y, z, flipX, isRoof] */
  placements: [string, number, number, number, number, number][];
}

/** Один готовий до малювання тайл. */
export interface DrawItem {
  img: HTMLImageElement;
  x: number; y: number; w: number; h: number;
  frames: number; frameMs: number;
  flip: boolean;
  z: number;
  /** Ордината "основи" об'єкта — за нею сортуємо глибину. */
  sortY: number;
}

export interface View { left: number; top: number; right: number; bottom: number; }

export class MapRenderer {
  bounds = { minX: 0, minY: 0, maxX: 0, maxY: 0 };
  private ground: DrawItem[] = [];
  private upright: DrawItem[] = [];

  async load(): Promise<void> {
    const map = (await (await fetch("/assets/map.json")).json()) as MapFile;
    this.bounds = map.bounds;

    // Завантажуємо всі картинки тайлів паралельно.
    const imgs = new Map<string, HTMLImageElement>();
    await Promise.all(
      Object.keys(map.tiles).map(
        (id) => new Promise<void>((resolve) => {
          const img = new Image();
          img.onload = () => resolve();
          img.onerror = () => resolve();
          img.src = `/assets/tiles/${id}.png`;
          imgs.set(id, img);
        }),
      ),
    );

    for (const [id, x, y, z, flip] of map.placements) {
      const t = map.tiles[id]!;
      const item: DrawItem = {
        img: imgs.get(id)!, x, y, w: t.w / t.frames, h: t.h, frames: t.frames, frameMs: t.frameMs,
        flip: flip === 1, z, sortY: y + t.h * t.py,
      };
      (z < GROUND_Z_LIMIT ? this.ground : this.upright).push(item);
    }
    this.ground.sort((a, b) => a.z - b.z || a.sortY - b.sortY);
    this.upright.sort((a, b) => a.sortY - b.sortY || a.z - b.z);
  }

  /** Малює землю. */
  drawGround(ctx: CanvasRenderingContext2D, v: View, now: number): void {
    for (const it of this.ground) this.drawItem(ctx, it, v, now);
  }

  /** Видимі "вертикальні" тайли (для змішування з гравцями). */
  visibleUpright(v: View): DrawItem[] {
    return this.upright.filter((it) => it.x < v.right && it.x + it.w > v.left && it.y < v.bottom && it.y + it.h > v.top);
  }

  drawItem(ctx: CanvasRenderingContext2D, it: DrawItem, v: View, now: number): void {
    if (it.x >= v.right || it.x + it.w <= v.left || it.y >= v.bottom || it.y + it.h <= v.top) return;
    const frame = it.frames > 1 ? Math.floor(now / it.frameMs) % it.frames : 0;
    if (it.flip) {
      ctx.save();
      ctx.translate(it.x + it.w, it.y);
      ctx.scale(-1, 1);
      ctx.drawImage(it.img, frame * it.w, 0, it.w, it.h, 0, 0, it.w, it.h);
      ctx.restore();
    } else {
      ctx.drawImage(it.img, frame * it.w, 0, it.w, it.h, it.x, it.y, it.w, it.h);
    }
  }
}
